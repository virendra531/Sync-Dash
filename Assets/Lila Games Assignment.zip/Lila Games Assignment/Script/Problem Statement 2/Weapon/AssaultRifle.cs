using UnityEngine;

public class AssaultRifle : Weapon
{
    public AssaultRifle() : base("Assault Rifle", WeaponType.Primary, GameConstants.AssaultRifleMaxAmmo, 30, GameConstants.AssaultRifleFireRate, GameConstants.AssaultRifleReloadTime) { }

    protected override void OnFire()
    {
        // Implement specific firing logic (e.g., projectile spawning, VFX)
    }
}
