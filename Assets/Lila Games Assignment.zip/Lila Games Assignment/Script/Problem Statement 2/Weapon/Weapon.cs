using UnityEngine;
using System;
using System.Collections.Generic;

// Enum for weapon types
public enum WeaponType
{
    Primary,
    Secondary
}

// Base Weapon class to handle common weapon properties and behavior
public abstract class Weapon
{
    public string WeaponName { get; protected set; }
    public WeaponType Type { get; protected set; }
    public int CurrentAmmo { get; protected set; }
    public int MaxAmmo { get; protected set; }
    public int MagazineSize { get; protected set; } // Size of the magazine means how many bullets can be fired before needing to reload
    public float FireRate { get; protected set; } // Shots per second
    public float ReloadTime { get; protected set; }
    public bool IsReloading { get; protected set; }
    protected float lastFireTime;

    public Weapon(string name, WeaponType type, int maxAmmo, int magazineSize, float fireRate, float reloadTime)
    {
        WeaponName = name;
        Type = type;
        MaxAmmo = maxAmmo;
        CurrentAmmo = magazineSize;
        MagazineSize = magazineSize;
        FireRate = fireRate;
        ReloadTime = reloadTime;
        IsReloading = false;
        lastFireTime = 0f;
    }

    public virtual bool CanFire()
    {
        return !IsReloading && CurrentAmmo > 0 && Time.time >= lastFireTime + (1f / FireRate);
    }

    public virtual void Fire()
    {
        if (CanFire())
        {
            CurrentAmmo--;
            lastFireTime = Time.time;
            OnFire();
            Debug.Log($"{WeaponName} fired. Ammo left: {CurrentAmmo}/{MagazineSize}");
        }
    }

    public virtual void Reload()
    {
        if (!IsReloading && CurrentAmmo < MagazineSize && MaxAmmo > 0)
        {
            IsReloading = true;
            Debug.Log($"{WeaponName} reloading...");
            
            int ammoNeeded = MagazineSize - CurrentAmmo;
            int ammoToTake = Mathf.Min(ammoNeeded, MaxAmmo);
            MaxAmmo -= ammoToTake;
            CurrentAmmo += ammoToTake;
            IsReloading = false;
            Debug.Log($"{WeaponName} reloaded. Ammo: {CurrentAmmo}/{MagazineSize}, Reserve: {MaxAmmo}");
        }
    }

    protected abstract void OnFire(); // Override for specific weapon effects
}