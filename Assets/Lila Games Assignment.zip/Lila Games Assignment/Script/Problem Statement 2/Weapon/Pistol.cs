using UnityEngine;

public class Pistol : Weapon
{
    public Pistol() : base("Pistol", WeaponType.Secondary, GameConstants.PistolMaxAmmo, 12, GameConstants.PistolFireRate, GameConstants.PistolReloadTime) { }

    protected override void OnFire()
    {
        // Implement specific firing logic
    }
}
