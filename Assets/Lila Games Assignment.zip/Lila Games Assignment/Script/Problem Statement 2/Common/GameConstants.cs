public static class GameConstants
{
    public const int MaxPrimaryWeapons = 2;
    public const int MaxSecondaryWeapons = 1;

    // Assault Rifle-specific constants
    public const int AssaultRifleMaxAmmo = 90;      // Higher reserve ammo
    public const float AssaultRifleFireRate = 10f;   // Faster fire rate (shots per second)
    public const float AssaultRifleReloadTime = 2f;  // Longer reload time

    // Pistol-specific constants
    public const int PistolMaxAmmo = 40;            // Lower reserve ammo
    public const float PistolFireRate = 2f;         // Slower fire rate
    public const float PistolReloadTime = 1.5f;     // Shorter reload time
}