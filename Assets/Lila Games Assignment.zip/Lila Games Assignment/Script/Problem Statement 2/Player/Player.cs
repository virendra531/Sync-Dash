using System;
using UnityEngine;

public class Player : MonoBehaviour
{
    private Weapon[] primaryWeapons = new Weapon[2];
    private Weapon secondaryWeapon;
    private Weapon currentWeapon;
    private int currentPrimaryIndex = 0;

    // public event Action<Weapon> OnWeaponChanged; // Event for UI updates
    // public event Action OnAmmoChanged; // Event for UI updates

    public void EquipWeapon(Weapon weapon)
    {
        if (weapon.Type == WeaponType.Primary && primaryWeapons[0] == null)
        {
            primaryWeapons[0] = weapon;
            currentWeapon = weapon;
        }
        else if (weapon.Type == WeaponType.Primary && primaryWeapons[1] == null)
        {
            primaryWeapons[1] = weapon;
            currentWeapon = weapon;
        }
        else if (weapon.Type == WeaponType.Secondary)
        {
            secondaryWeapon = weapon;
            currentWeapon = weapon;
        }

        // OnWeaponChanged?.Invoke(currentWeapon);
        EventManager.TriggerEvent("WeaponChanged", currentWeapon);
        Debug.Log($"Equipped {weapon.WeaponName}");
    }

    public void SwitchWeapon()
    {
        if (secondaryWeapon == null && primaryWeapons[1] == null) return;

        if (currentWeapon == secondaryWeapon)
        {
            currentWeapon = primaryWeapons[currentPrimaryIndex];
        }
        else
        {
            if (secondaryWeapon != null)
            {
                currentWeapon = secondaryWeapon;
            }
            else
            {
                currentPrimaryIndex = (currentPrimaryIndex + 1) % 2;
                if (primaryWeapons[currentPrimaryIndex] != null)
                {
                    currentWeapon = primaryWeapons[currentPrimaryIndex];
                }
            }
        }

        // OnWeaponChanged?.Invoke(currentWeapon);
        Debug.Log($"Switched to {currentWeapon.WeaponName}");
    }

    public void FireWeapon()
    {
        if (currentWeapon != null)
        {
            currentWeapon.Fire();
            // OnAmmoChanged?.Invoke();
            EventManager.TriggerEvent("AmmoChanged");
        }
    }

    public void ReloadWeapon()
    {
        if (currentWeapon != null)
        {
            currentWeapon.Reload();
            // OnAmmoChanged?.Invoke();
            EventManager.TriggerEvent("AmmoChanged");
        }
    }

    public Weapon GetCurrentWeapon()
    {
        return currentWeapon;
    }
}
