using UnityEngine;

public class WeaponUIManager : MonoBehaviour
{
    private Player player;

    public void Initialize(Player player)
    {
        this.player = player;
        // player.OnWeaponChanged += UpdateWeaponDisplay;
        // player.OnAmmoChanged += UpdateAmmoDisplay;

        EventManager.Subscribe("WeaponChanged", data => UpdateWeaponDisplay(data as Weapon));
        EventManager.Subscribe("AmmoChanged", _ => UpdateAmmoDisplay());
    }

    private void UpdateWeaponDisplay(Weapon weapon)
    {
        // Update UI elements to show current weapon
        Debug.Log($"UI: Displaying {weapon.WeaponName} ({weapon.Type})");
    }

    private void UpdateAmmoDisplay()
    {
        if (player.GetCurrentWeapon() != null)
        {
            Weapon weapon = player.GetCurrentWeapon();
            Debug.Log($"UI: Ammo {weapon.CurrentAmmo}/{weapon.MagazineSize}, Reserve: {weapon.MaxAmmo}");
        }
    }

    private void OnDestroy()
    {
        if (player != null)
        {
            // player.OnWeaponChanged -= UpdateWeaponDisplay;
            // player.OnAmmoChanged -= UpdateAmmoDisplay;

            EventManager.Unsubscribe("WeaponChanged", data => UpdateWeaponDisplay(data as Weapon));
            EventManager.Unsubscribe("AmmoChanged", _ => UpdateAmmoDisplay());
        }
    }
}
