using UnityEngine;

public class RemotePlayerController : MonoBehaviour
{
    public float lerpSpeed = 10f; // Matches sendInterval (1/0.1s = 10)
    private Vector3 initialPosition;
    private Vector3 targetPosition;
    private Vector2 lastReceivedPosition;

    void Awake()
    {
        initialPosition = transform.position; // (22, 1, 0)
        targetPosition = initialPosition;
        lastReceivedPosition = new Vector2(0, 0); // Match MainPlayer's (0, 0)
    }

    public void ReceiveCompressedDeltaPosition(uint compressedData, Vector2 originalPos)
    {
        // Unpack delta (32 bits)
        int xSign = (int)((compressedData >> 31) & 0x1);
        int xQuantized = (int)((compressedData >> 16) & 0x7FFF); // 15 bits
        int zSign = (int)((compressedData >> 15) & 0x1);
        int zQuantized = (int)(compressedData & 0x7FFF); // 15 bits

        float xDelta = (xQuantized / 32767f) * 50f;
        float zDelta = (zQuantized / 32767f) * 50f;
        xDelta = xSign == 1 ? -xDelta : xDelta;
        zDelta = zSign == 1 ? -zDelta : zDelta;

        Vector2 newPos = lastReceivedPosition + new Vector2(xDelta, zDelta);
        targetPosition = new Vector3(newPos.x, 0, newPos.y) + initialPosition;
        lastReceivedPosition = newPos;

        Debug.Log($"Received Position (Delta): {newPos}, Original: {originalPos}, DataSize: <color=yellow>{sizeof(uint) * 8} bits</color>");
    }

    void Update()
    {
        transform.position = Vector3.Lerp(transform.position, targetPosition, Time.deltaTime * lerpSpeed);
    }
}