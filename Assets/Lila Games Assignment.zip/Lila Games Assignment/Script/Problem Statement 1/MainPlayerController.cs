using UnityEngine;
using UnityEngine.InputSystem;

public class MainPlayerController : MonoBehaviour
{
    public float moveSpeed = 5f;
    public RemotePlayerController remotePlayer;
    private Vector2 lastSentPosition;
    private float sendInterval = 0.1f;
    private float timer;
    private Vector3 previousPosition;

    void Start()
    {
        lastSentPosition = new Vector2(transform.position.x, transform.position.z);
        previousPosition = transform.position;
    }

    void Update()
    {
        float moveX = Keyboard.current.aKey.isPressed ? -1f : Keyboard.current.dKey.isPressed ? 1f : 0f;
        float moveZ = Keyboard.current.sKey.isPressed ? -1f : Keyboard.current.wKey.isPressed ? 1f : 0f;
        Vector3 movement = new Vector3(moveX, 0, moveZ).normalized * moveSpeed * Time.deltaTime;
        transform.position += movement;

        timer += Time.deltaTime;
        if (timer >= sendInterval)
        {
            float distance = Vector3.Distance(transform.position, previousPosition);
            if (distance > 0.01f) // Send only if moved significantly
            {
                SendCompressedDelta();
                previousPosition = transform.position;
            }
            timer = 0f;
        }
    }

    void SendCompressedDelta()
    {
        Vector2 currentPos = new Vector2(transform.position.x, transform.position.z);
        Vector2 delta = currentPos - lastSentPosition;

        // Delta compression (-50 to 50 units)
        int xSign = delta.x < 0 ? 1 : 0;
        int zSign = delta.y < 0 ? 1 : 0;
        float xAbs = Mathf.Abs(delta.x);
        float zAbs = Mathf.Abs(delta.y);
        int xQuantized = Mathf.FloorToInt(Mathf.Clamp(xAbs, 0, 50) / 50f * 32767f); // 15 bits
        int zQuantized = Mathf.FloorToInt(Mathf.Clamp(zAbs, 0, 50) / 50f * 32767f); // 15 bits

        // Pack into 32 bits: [xSign (1), xMag (15), zSign (1), zMag (15)]
        uint compressedData = (uint)((xSign << 31) | (xQuantized << 16) | (zSign << 15) | zQuantized);

        // Debug.Log($"Sent Delta: {delta}, Quantized: ({(xSign == 1 ? "-" : "")}{xQuantized}, {(zSign == 1 ? "-" : "")}{zQuantized}), Size: 32 bits");

        remotePlayer.ReceiveCompressedDeltaPosition(compressedData, currentPos);
        lastSentPosition = currentPos;
    }
}